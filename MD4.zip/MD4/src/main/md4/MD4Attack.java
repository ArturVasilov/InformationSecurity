package main.md4;

/**
 * @author Artur Vasilov
 */
public class MD4Attack {

    public static String findCollisionMessage(String hash) {
        //TODO : write attack algorithm
        return "123456";
    }

}
